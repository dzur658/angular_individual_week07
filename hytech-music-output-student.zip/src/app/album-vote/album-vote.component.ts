import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-album-vote',
  templateUrl: './album-vote.component.html',
  styleUrls: ['./album-vote.component.css']
})
export class AlbumVoteComponent {
  @Output() vote = new EventEmitter<boolean>();
  votebinder(val:boolean) {
    this.vote.emit(val);
  }
}