export interface Album {
  artist: string;
  coverUrl: string;
  title: string;
  releaseDate: Date;
  trackList: string[];
  albumOwned: boolean;
}
