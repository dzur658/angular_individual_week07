import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { AlbumHeaderComponent } from './album-header/album-header.component';
import { PlayButtonComponent } from './play-button/play-button.component';
import { TrackComponent } from './track/track.component';
import { BuyButtonComponent } from './buy-button/buy-button.component';
import { AlbumVoteComponent } from './album-vote/album-vote.component';

@NgModule({
  imports:      [ BrowserModule, FormsModule ],
  declarations: [ AppComponent, HelloComponent, AlbumHeaderComponent, PlayButtonComponent, TrackComponent, BuyButtonComponent, AlbumVoteComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
