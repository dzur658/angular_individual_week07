import { Component, EventEmitter, Output } from '@angular/core';




@Component({
  selector: 'app-buy-button',
  templateUrl: './buy-button.component.html',
  styleUrls: ['./buy-button.component.css']
})
export class BuyButtonComponent {
  @Output() clickedEmit = new EventEmitter<string>();
  wasClicked:boolean = false;

  onButtonClick(thingIWantToSay:string) {
    this.clickedEmit.emit(thingIWantToSay);
    this.wasClicked = true;
  }
}